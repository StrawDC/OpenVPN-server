﻿<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
$host = "localhost"; //MYSQL主机
$port = 3306; //MYSQL主机
$user = "root"; //MYSQL用户
$pwd ="kywlpass"; //MYSQL密码
$dbname = "Kyml";
$admintwopass = "kywltwopass";//本地二级密码
?>