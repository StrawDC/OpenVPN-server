<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='../Kyun';</script>");
$res=$DB->get_row("SELECT * FROM auth_daili where `id`='{$dlid}'");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title> - 线路列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;width: 100%">
<section class="panel panel-default">
  <div class="ibox-title">
                        <h5>线路列表 <small>线路文件列表</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
<div class="panel-body">
				
<div class="form-group">
<?php
$my=isset($_GET['my'])?$_GET['my']:null;
if($my=='del'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除线路结果</h3></div>
<div class="panel-body box">';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `line` WHERE id='$id'");
if($sql){echo '恭喜亲删除该线路成功';}
else{echo '噢，删除线路失败,请稍后重新尝试.！';}
echo '<hr/><a href="./line_list.php" class="btn btn-success">返回线路列表</a></div></div>';exit;
}elseif($my=='yys'){
$sql="`group`='{$_GET['gid']}' && `dlid` ='{$dlid}'";
$numrows=$DB->count("SELECT count(*) from `line` WHERE {$sql}");
}else{
$sql = "`dlid` ='{$dlid}'";	
$numrows=$DB->count("SELECT count(*) from `line` WHERE `dlid` ='{$dlid}'");}
$con='平台共有 <b>'.$numrows.'</b> 条线路';
echo '<form><a href="line_list.php" class="btn btn-primary">全部显示</a> &nbsp;';
$ri=$DB->query("SELECT * FROM line_grop");
while($ros = $DB->fetch($ri)){
echo '<a href="line_list.php?my=yys&gid=',$ros['id'],'" class="btn btn-success">',$ros['name'],'</a> &nbsp;';}	
echo '<a href="#" class="btn btn-info"><b>'.$con.'</b></a>
</form>';

?>
       <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead><tr><th class="text-center">ID</th><th class="text-center">名称</th><th class="text-center">状态</th><th class="text-center">描述</th><th class="text-center">添加时间</th><th class="text-center">管理操作</th></tr></thead>
           <tbody>
<?php
$pagesize=100;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM `line` WHERE {$sql} order by id desc limit {$offset},${pagesize}");
while($res = $DB->fetch($rs)){
?>
<tr>
<td class="text-center" width="5%"><?=$res['id']?></td>
<td class="text-center"width="10%"><?=$res['name']?></td>
<td class="text-center"width="5%"><span class="label label-primary">已启用</span></td>
<td><?=$res['label']?></td>
<td class="text-center" width="10%"><?=$res['type']?></td>
<td class="text-center"><a href="./set_line.php?id=<?=$res['id']?>" class="btn btn-xs btn-success">编辑</a>&nbsp;<a href="./line_list.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="line_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="line_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="line_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="line_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="line_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="line_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
    </div>

 
                  
              </div>
            </section>
			  </div>
                        </div>
                    </div>
                </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>


    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    </body>
</html>
