<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$dlid=$_SESSION['dlid'];
if($dlid<>""){
$row = $DB->get_row("SELECT * FROM kyun"); 	
echo '
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width initial-scale=1.0 maximum-scale=1.0 user-scalable=no" />
    <meta name="renderer" content="webkit">

    <title>'.$row[logo].' - 管理后台</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">

    <link rel="shortcut icon" href="../../asstes/img/favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
	
</head>
<body class="fixed-sidebar full-height-layout gray-bg" style="overflow:hidden">
    <div id="wrapper">
	 <!--左侧导航开始-->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="nav-close"><i class="fa fa-times-circle"></i>
            </div>
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="N17_daili.php">
                                <span class="clear">
                                    <span class="block m-t-xs" style="font-size:20px;">
									<img alt="image" class="img-circle"  height="160" width="160" src="'.$row[logo2].'"></img>
                                    </span>
                                </span>
                               </a>
                           </div>
						<div class="logo-element"><img alt="image" class="img-circle"  height="70" width="70" src="'.$row[logo2].'">
                       </div>
                     </li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">数据信息</span>
                    </li>
                    <li>
                        <a class="J_menuItem" href="N17_daili.php">
                            <i class="fa fa-home"></i>
                            <span class="nav-label">平台首页</span>
                        </a>
                    </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">用户信息</span>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-qq fa-fw"></i><span class="nav-label">账号管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          <li><a class="J_menuItem" href="add_user.php">添加账号</a>
                            </li>
							<li><a class="J_menuItem" href="padd_user.php">批量添加账号</a>
                            </li>
							 <li>
                                <a class="J_menuItem" href="user_list.php">账号列表</a>
                            </li>
                        </ul>
                    </li>
					<li>
					 <a href="#"><i class="fa fa-book"></i><span class="nav-label">卡密管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
						 <li><a class="J_menuItem" href="kms_list.php">卡密列表</a>
                            </li>
						 </ul>
                    </li>
					<li>
                        <a href="#"><i class="fa fa-shield"></i><span class="nav-label">线路管理</span><span class="label label-warning pull-right">New</span></a>
						 <ul class="nav nav-second-level">
							<li><a class="J_menuItem" href="add_line.php">添加新线路</a>
                            </li>
                         <li><a class="J_menuItem" href="line_list.php">线路列表</a>
                            </li>
                        </ul>
					 </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">平台信息</span>
                    </li>
					 <li>
                        <a href="#"><i class="fa fa-cube"></i><span class="nav-label">套餐管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                           <li>
						    <a class="J_menuItem" href="add_taocan.php">添加新套餐</a>
                            </li>
							 <li><a class="J_menuItem" href="taocan_list.php">套餐列表</a>
                            </li>
                            <li><a class="J_menuItem" href="pay_set.php">支付接口设置</a>
                            </li>
							<li><a class="J_menuItem" href="buy_list.php">交易记录列表</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-comments"></i><span class="nav-label">信息管理</span><span class="label label-danger pull-right">Hot</span></a>
                        <ul class="nav nav-second-level">
						 <li><a class="J_menuItem" href="app_qq.php">软件客服</a>
                            </li>
							 <li><a class="J_menuItem" href="add_ggao.php">添加新公告</a>
                            </li>
                            <li><a class="J_menuItem" href="ggao_list.php">公告列表</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-user-md"></i><span class="nav-label">高级管理</span><span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
							<li><a class="J_menuItem" href="pass_set.php">修改密码</a>
                            </li>
                        </ul>
                    </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">服务信息</span>
                    </li>
					<li>
                        <a href="../Kyun/index.php?logout"><i class="fa fa-sign-in"></i><span class="nav-label">退出登录</span></a>
				    </li>
                    <li>
                        <a href="#"><i class="fa fa-gears"></i><span class="nav-label">系统版本信息 </span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a class="J_menuItem">PHP 版本：5.4.45  </a>
                            </li>
                            <li><a class="J_menuItem">MySQL 版本：5.5.52</a>
                            </li>
                            <li><a class="J_menuItem">WEB 版本：N17-6.0  </a>
                            </li>
                        </ul>
                    </li>
                 </ul>
			   <br>
            </div>
        </nav>
        <!--左侧导航结束-->
        <!--右侧部分开始-->
         <div id="page-wrapper" class="gray-bg dashbard-1">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header"><a class="navbar-minimalize minimalize-styl-2 btn btn-info " href="#"><i class="fa fa-bars"></i> </a>
                        <form role="search" class="navbar-form-custom" method="post" action="#">
                            <div class="form-group">
                                <input type="text" placeholder="OpenVPN丨'.$row[logo].'" class="form-control" name="top-search" id="top-search">
                            </div>
                        </form>
                    </div> 
				   <div class="pull-right tooltip-demo">
                         <a class="btn btn-sm btn-white" href="../Kyun/index.php?logout"><i class="fa fa-sign-out fa-arrow-right"></i> 注销</a>
                        </div>
                </nav>
            </div>
        <div class="row J_mainContent" id="content-main">
                <iframe id="J_iframe" width="100%" height="100%" src="N17_daili.php" frameborder="0" data-id="N17_daili.php" seamless></iframe>
         </div>  
     <!--右侧部分结束-->
    </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="../../assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../../assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="../../assets/js/plugins/layer/layer.min.js"></script>

    <!-- 自定义js -->
    <script src="../../assets/js/hAdmin.js?v=4.1.0"></script>
    <script type="text/javascript" src="../../assets/js/index.js"></script>

    <!-- 第三方插件 -->
    <script src="../../assets/js/plugins/pace/pace.min.js"></script>
</body>

</html>';
}else{
exit("<script language='javascript'>window.location.href='../Kyun/login.php';</script>");}
?>
