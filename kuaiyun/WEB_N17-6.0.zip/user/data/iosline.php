﻿<?php
require("../../Kyws/system.php");
$u = @$_GET['user'];
$p = @$_GET['pass'];
$res=db(_openvpn_)->where(array(_iuser_=>$u,_ipass_=>$p))->find();
if(!$res){exit("<script language='javascript'>alert('账号密码错误或不存在！');window.location.href='../data/index.php?user={$u}&pass={$p}';</script>");}
if($res['i']=='0'){exit("<script language='javascript'>alert('账号未激活或流量不足！');window.location.href='../data/index.php?user={$u}&pass={$p}';</script>");}
$ip = getvip();
$is_location = true;
$api_uri = "http://ip.taobao.com/service/getIpInfo.php?ip=$ip";
$json = file_get_contents($api_uri);
$arr = json_decode($json,true);
if($arr["code"] != "0"){
	$ispno = true;
}
$isp    = '中国'.$arr["data"]["isp"]; //运行商 eg 电信
$isps    = $arr["data"]["isp"]; //运行商 eg 电信
$region = $arr["data"]["region"]; //省份 eg 河北省
$ip     = getvip(); //用户IP eg 123.57.89.18
$find = str_replace("省","",$region);
$find = str_replace("市","",$find);
$find = str_replace("壮族自治区","",$find);
$find = str_replace("维吾尔自治区","",$find);
$find = str_replace("回族自治区","",$find);
$find = str_replace("自治区","",$find);
$cid = db('line_grop')->where(array("show"=>1,'name'=>$isp))->find();
$logo = db('kyun')->where(array())->find();
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width; initial-scale=1.0; minimum-scale=1.0; maximum-scale=2.0">
<title>苹果用户线路下载</title>
<style type="text/css">
* { padding: 0; margin: 0; list-style: none; text-decoration: none; }
body{font:1pc/30px "Microsoft YaHei";line-height:0px;font-size:0px;}
.main,body{background:#f2f2f2;}
.main{margin:0 auto;max-width:45pc;line-height:30px;}
.logo {padding-top: 30px; background: #fff;}
.logo img {width: 100px; text-align: center; display: block;margin: 0 auto;}
.tip{margin-bottom:15px;padding:25px 10px;font-size:15px}
.tip,.tips{background:#fff;color:#777;text-align:center}
.tips{margin-top:15px;padding:15px 10px;font-size:14px}
.xianlu{padding:20px;background:#fff}
.xianlu h3{margin-bottom:15px;color:#333;text-align:center;font-size:18px}
.form-control{background: #ffffff;margin:0 auto;margin-bottom:25px;min-width:80%;display:block;width:80%;height:40px;padding:6px 9pt;font-size:14px;line-height:1.428571429;color:#555;vertical-align:middle;background-color:#fff;border:1px solid #ccc;border-radius:3px;box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;}
.btn-upapp{background:#007aff;color:#fff}
.btn-l{display:block;margin:0 auto;height:40px;min-width:80%;border:none;border-radius:3px;text-align:center;font-size:14px;line-height:36px}
.btn{cursor:pointer;-webkit-transition:all ease-in-out .4s;transition:all ease-in-out .4s;-ms-transition:all ease-in-out .4s}
</style>
<script src="//cdn.bootcss.com/jquery/2.0.0/jquery.min.js"></script>


</head>

<body>
	<div class="main">
	<div class="logo"><img src="<?php echo $logo['logo2'];?>"></div>

		<div class="tip">此页面仅供ios用户安装免流线路使用</br>
			请使用苹果自带的safari浏览器下载安装
		</div>
		<div class="xianlu">
		<form action="download.php?user=<?php echo $_GET["user"]?>&pass=<?php echo $_GET["pass"]?>" method="post">
			<div class="tip">
				--=自动定位：<?php echo $isp;?><?php echo $region; ?>=--
			</div>
           <input name="cid" value="<?php echo $cid['id'];?>" type="hidden"/>
		   <input name="isps" value="<?php echo $isps;?>" type="hidden"/>
		   <input name="region" value="<?php echo $region;?>" type="hidden"/>
			<h3>第一步：选择节点</h3>
			<select class="form-control" name="note">
					<?php
					$vo = db("ky_fz")->select();
					foreach($vo as $fz){
                     echo "<option value='".$fz['id']."'>" . $fz['name'] . "</option>";
					}
					?>
				</select>
			<h3>第二步：选择线路</h3>
			<h4>	
			<select class="form-control" name="axid">
			<option value='ABC'>为你推荐的地区线路</option>
			<?php
				$voo = db("line")->where("`show`=1 AND `group`=:select_id AND (label LIKE '%".$find."%' OR name LIKE '%".$find."%')",array(":select_id"=>$cid['id']))->select();
					foreach($voo as $line){
                     echo "<option value='".$line['id']."'>" . $line['name'] . "</option>";
					}
					?>
			</select>
			<select class="form-control" name="bxid">
			<option value='ABC'>为你推荐的全国线路</option>
			<?php
				$voo = db("line")->where("`show`=1 AND `group`=:select_id AND (label LIKE '%全国%' OR label LIKE '%通用%' OR label LIKE '%不限地区%' OR `name` LIKE '%全国%' OR `name` LIKE '%通用%' OR `name` LIKE '%不限地区%')",array(":select_id"=>$cid['id']))->select();
					foreach($voo as $line){
                     echo "<option value='".$line['id']."'>" . $line['name'] . "</option>";
					}
					?>
			</select>
			<button class="btn btn-l btn-upapp" type="submit">安装线路</button>
		</div>
		<div class="tips">点击下载后请使用openvpn的方式打开即可导入线路</div>
	</div>
</body>
</html>
