﻿<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$row = $DB->get_row("SELECT * FROM kyun"); 	
?>
<html lang="en"> 
<head>
<title><?=$row['logo']?>APP官方下载</title>
<meta charset="utf-8"/>
<meta name="applicable-device" content="pc,mobile"/>
<meta name="renderer" content="webkit"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css"/>
<link rel="stylesheet" href="css/style_down_page.css" type="text/css"/>
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css"/>
<link rel="stylesheet" href="css/sweetalert.css"/>
</head>
<body>
<div class="row-fluid breadcrumbs margin-bottom-20">
<div class="container">
<h1 class="pull-left"><?=$row['logo']?>App</h1>
<ul class="pull-right breadcrumb">
<li>版本：5.5.1</li>
<li>大小：2.67 M</li>
<li>2017-09-9</li>
</ul>
</div>
</div>
<div class="container content">
<div class="view row">
<div class="span12">
<a href="javascript:void(0)"><img src="<?=$row['logo2']?>" class="appicon"/></a>
</div>
</div>
<div class="view row margin-top-30">
<div class="span12 margin-bottom-20">
<div class="spinner">
<a id="appdown" href="./app.apk" target="_blank" class="btn-u btn-u-lg">
<img style="height:30px;" src="./download-logo.png">点击下载</a>
</div>
</div>
<div class="span12">
<span class="label label-success">适用于 Android 设备</span>
<br/><br/>
<a href="/ios.html" class="label label-info">iOS苹果？</a>
</div>
</div>
<hr class="devider devider-dotted">
<div class="view row margin-bottom-30">
<div class="span12">
或者用手机扫描下面的二维码进行下载安装
<br/>
<br/>
<img src="http://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php $value = 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/user/app';echo $value;?>" style="width: 205px;height: 205px;"/>
</div>
</div>
</div>
<div class="devider-down">
<p>Copyright © 2017 <?=$row['logo']?></a></p>
</div>
<script src="js/jquery-2.2.0.min.js"></script>
<script src="js/sweetalert.min.js"></script>
<script src="js/js_sdk.js"></script>
</body>
</html>