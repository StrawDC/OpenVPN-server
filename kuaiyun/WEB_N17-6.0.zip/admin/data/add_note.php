<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>负载集群管理 - 添加节点</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>负载集群管理 >><small>添加节点</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
<?php
if($_POST['name']){
echo '
<div class="panel-heading w h"><h3 class="panel-title">添加节点结果</h3></div>
<div class="panel-body box">';	
$name = daddslashes($_POST['name']);
$ipport = daddslashes($_POST['ipport']);
$type = daddslashes($_POST['type']);
$maximum = daddslashes($_POST['maximum']);
$order = daddslashes($_POST['order']);
if(!$DB->get_row("select * from `ky_fz` where `name`='$name' limit 1")){
$sql="insert into `ky_fz` (`name`,`ipport`,`type`,`maximum`,`order`) values ('{$name}','{$ipport}','{$type}','{$maximum}','{$order}')";
if($DB->query($sql))
echo '<div class="box">恭喜亲，成功添加一个节点</div>';
else
echo '<div class="box">奥，添加节点失败,请稍后重新尝试.</div>';
}else{
echo '<div class="box">亲，该节点已经存在,请不要重复添加.</div>';
}
echo '<hr/><a href="./note_list.php" class="btn btn-success">返回节点列表</a></div></div>';}
else{
echo'			
                        <form action="./add_note.php" class="form-horizontal m-t" method="post">
						    <div class="form-group has-error"> 
                                <label class="col-sm-3 control-label">节点名称</label>
                                <div class="col-sm-8">
                                    <input name="name" placeholder="湖南节点" class="form-control" type="text">
                                 </div>
								</div>
								
							 <div class="hr-line-dashed"></div>
                   
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">节点地址</label>
                                <div class="col-sm-8">
                                    <input name="ipport" placeholder="hunan.kuaiyum.com" class="form-control" type="text">
                                </div>
							  </div>
							  <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-warning">
                                <label class="col-sm-3 control-label">满载人数</label>
                                <div class="col-sm-8">
                                    <input name="maximum" placeholder="默认为200人" class="form-control" type="text">
                                </div>
							  </div>
							   <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">排序列表</label>
                                <div class="col-sm-8">
                                    <input name="order" placeholder="数字越小在APP内排名越靠前" class="form-control" type="text">
                                </div>
							  </div>
							 <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-error">
                                <label class="col-sm-3 control-label">节点描述</label>
                                <div class="col-sm-8">
                                    <input name="type" placeholder="玩游戏/看视频/下软件" class="form-control" type="text">
                                </div>
							  </div>
							 <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-3">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>';
}								
?>		
                    </div>
                </div>
            </div>
        </div>

    </div>
    

</body>

</html>
