<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
$user=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
$ok_user = $DB->count("SELECT count(*) from `openvpn` WHERE i=1");
$all_udp=$DB->count("SELECT count(*) from `openvpn` WHERE online=1 && `xieyi`='udp'");
$all_tcp=$DB->count("SELECT count(*) from `openvpn` WHERE online=1 && `xieyi`='tcp-server'");
$all_online=$DB->count("SELECT count(*) from `openvpn` WHERE online=1");
$bfl_udp = $all_udp / $ok_user * 100;
$bfl_tcp = $all_tcp / $ok_user * 100;
$dallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-11 day"))."'");
$eallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-10 day"))."'");
$fallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-9 day"))."'");
$gallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-8 day"))."'");
$hallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-7 day"))."'");
$iallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-6 day"))."'");
$jallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-5 day"))."'");
$kallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-4 day"))."'");
$lallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-3 day"))."'");
$mallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-2 day"))."'");
$oallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date("Y-m-d",strtotime("-1 day"))."'");
$pallKB = $DB->count("SELECT sum(`data`) from `top` WHERE `time`='".date('Y-m-d')."'");
$today = date('d');
if($today <= '12'){
$xxmax = 12;
$xxmin = 1;
$data1 = 1;
$data2 = 2;
$data3 = 3;
$data4 = 4;
$data5 = 5;
$data6 = 6;
$data7 = 7;
$data8 = 8;
$data9 = 9;
$data10 = 10;
$data11 = 11;
$data12 = 12;
if($today == '1'){
$a = array(
		floor($pallKB/1024/1024/1024),0,0,0,0,0,0,0,0,0,0,0,0,
  );
}elseif($today == '2'){
$a = array(
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,0,0,0,0,0,0,0,0,
  );
}elseif($today == '3'){
$a = array(
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,0,0,0,0,0,0,0,
  );
}elseif($today == '4'){
$a = array(
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,0,0,0,0,0,0,
  );
}elseif($today == '5'){
$a = array(
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,0,0,0,0,0,
  );
}elseif($today == '5'){
$a = array(
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,0,0,0,0,
  );
}elseif($today == '6'){
$a = array(
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,0,0,0,
  );
}elseif($today == '7'){
$a = array(
		floor($iallKB/1024/1024/1024),
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,0,0,
  );
}elseif($today == '8'){
$a = array(
		floor($hallKB/1024/1024/1024),
		floor($iallKB/1024/1024/1024),
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,0,
  );
}elseif($today == '9'){
$a = array(
		floor($gallKB/1024/1024/1024),
		floor($hallKB/1024/1024/1024),
		floor($iallKB/1024/1024/1024),
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,0,
  );
}elseif($today == '10'){
$a = array(
		floor($fallKB/1024/1024/1024),
		floor($gallKB/1024/1024/1024),
		floor($hallKB/1024/1024/1024),
		floor($iallKB/1024/1024/1024),
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,0,
  );
}elseif($today == '11'){
$a = array(
		floor($eallKB/1024/1024/1024),
		floor($fallKB/1024/1024/1024),
		floor($gallKB/1024/1024/1024),
		floor($hallKB/1024/1024/1024),
		floor($iallKB/1024/1024/1024),
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),0,
  );
}elseif($today == '12'){
$a = array(
		floor($dallKB/1024/1024/1024),
		floor($eallKB/1024/1024/1024),
		floor($fallKB/1024/1024/1024),
		floor($gallKB/1024/1024/1024),
		floor($hallKB/1024/1024/1024),
		floor($iallKB/1024/1024/1024),
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024),
  );
}}else{
$xxmax = date("d");
$xxmin = date("d",strtotime("-11 day"));
$data1 = date("d",strtotime("-11 day"));
$data2 = date("d",strtotime("-10 day"));
$data3 = date("d",strtotime("-9 day"));
$data4 = date("d",strtotime("-8 day"));
$data5 = date("d",strtotime("-7 day"));
$data6 = date("d",strtotime("-6 day"));
$data7 = date("d",strtotime("-5 day"));
$data8 = date("d",strtotime("-4 day"));
$data9 = date("d",strtotime("-3 day"));
$data10 = date("d",strtotime("-2 day"));
$data11 = date("d",strtotime("-1 day"));
$data12 = date("d");
$a = array(
		floor($dallKB/1024/1024/1024),
		floor($eallKB/1024/1024/1024),
		floor($fallKB/1024/1024/1024),
		floor($gallKB/1024/1024/1024),
		floor($hallKB/1024/1024/1024),
		floor($iallKB/1024/1024/1024),
		floor($jallKB/1024/1024/1024),
		floor($kallKB/1024/1024/1024),
		floor($lallKB/1024/1024/1024),
		floor($mallKB/1024/1024/1024),
		floor($oallKB/1024/1024/1024),
		floor($pallKB/1024/1024/1024)
  );
}
$pos=max($a);
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="renderer" content="webkit">

    <title>管理员平台 - N17-6.0</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>	
<body class="gray-bg">
    <div class="wrapper wrapper-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="row row-sm text-center">
                            <div class="col-xs-6">
                                <div class="panel padder-v item">
                                    <div class="h1 text-info font-thin h1"><?php echo $user;?></div>
                                    <span class="text-muted text-xs">账号数量</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="panel padder-v item bg-info">
                                    <div class="h1 text-fff font-thin h1"><?php echo $ok_user;?></div>
                                    <span class="text-muted text-xs">正常账号</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-primary m-r-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="panel padder-v item bg-primary">
                                    <div class="h1 text-fff font-thin h1"><?php echo $all_online;?></div>
                                    <span class="text-muted text-xs">总在线人数</span>
                                    <div class="bottom text-left">
                                        <i class="fa fa-caret-up text-info m-l-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="panel padder-v item">
                                    <div class="font-thin h1"><?php echo date("H:i",time())?></div>
                                    <span class="text-muted text-xs">当前时间</span>
                                    <div class="bottom text-left">
                                        <i class="fa fa-caret-up text-warning m-l-sm"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title" style="border-bottom:none;background:#fff;">
                                <h5>流量状态(单位/G)</h5>
                            </div>
                            <div class="ibox-content" style="border-top:none;">
                                <div id="flot-line-chart-moving" style="height:217px;">正在加载中...</div>
                            </div>
                        </div>
                    </div>
                </div>
             <div class="row">
		  <div class="col-sm-6">
			<div class="row">
		<div class="col-sm-12">
	<div class="ibox">
	 <div class="ibox-content">
	  <h3><i class="fa fa-volume-up"></i> 官方公告列表</h3>
    <h3>快云</h3>
	 </div> 
	   </div> 
	     </div>
			<div class="col-sm-4">
                <div class="ibox">
                    <div class="ibox-content">
                        <h3><i class="fa fa-rss"></i> TCP协议</h3>
                        <h5>共 <?php echo $all_tcp;?>人在线&nbsp;在线率 <?php echo sprintf("%.1f", $bfl_tcp);?> %</h5>
						<br>
                        <div class="text-center">
                            <div id="sparkline6">加载中...</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="ibox">
                    <div class="ibox-content">
                        <h3><i class="fa fa-rss"></i> UDP协议</h3>
                        <h5>共 <?php echo $all_udp;?>人在线&nbsp;在线率 <?php echo sprintf("%.1f", $bfl_udp);;?>%</h5>
						<br>
                        <div class="text-center">
                            <div id="sparkline8">加载中...</div>
                        </div>
                    </div>
                </div>
            </div> 	
		 <div class="col-sm-4">
			 <div class="row">
			   <div class="col-sm-12">
				 <div class="ibox">
                    <div class="ibox-content">
					    <center>
                        <strong><h2 class="Netid">Loading</h2></strong>
						<h3>网速实时监控</h3>
						</center>
                      </div>
                     </div>
				    </div>
				  <div class="col-sm-12">
				 <div class="ibox">
                   <div class="ibox-content">
                     <center>
                        <strong><h2><?php 
						    exec("top -bn1 | grep Cpu",$cpuinfo);
		                    preg_match('/\s*([0-9\.]*)\s*id/is',$cpuinfo[0],$cpuinfo_free);
		                    $lyl = 100-(float)$cpuinfo_free[1];
							echo $lyl;?> %</h2></strong>
						<h3>当前CPU利用率</h3>
						</center>
                     </div>
                   </div>
		         </div>
			   </div>
		     </div>
			<div class="col-sm-12">
              <div class="row row-sm text-center">
			   <div class="col-xs-6">
			    <?php
                  $Ky = exec("Kps Ky");
                     if($Ky == 'ok'){
					    echo '<div class="panel panel-info"><div class="panel-heading"><h3>流量监控运行正常</h3></div></div> ';
					  }else{
					    echo '<div class="panel panel-danger"><div class="panel-heading"><h3>流量监控运行异常</h3></div></div> ';
					  }                  ?>
                </div>	
			 <div class="col-xs-6">
                <?php
                  $op = exec("Kps openvpn");  
                     if($op == 'ok'){
					    echo '<div class="panel panel-info"><div class="panel-heading"><h3>OPENVPN运行正常</h3></div></div> ';
					  }else{
					    echo '<div class="panel panel-danger"><div class="panel-heading"><h3>OPENVPN运行异常</h3></div></div> ';
					  }                      ?>
                  </div>
               </div>
            </div>			
			 <div class="col-sm-8">
               <div class="ibox">
                <div class="ibox-content">
                  <h3><i class="fa fa-globe"></i> 开启的TCP端口</h3>
                  <?php
                    exec(" netstat -nap|grep tcp|grep \"0 0.0.0.0:\"",$tcp);
                     preg_match_all("/\:([0-9]*)/",implode("\n",$tcp),$m);
                     foreach($m[1] as $v){ 
                     echo '<span class="label label-primary">'.$v.'</span> ';}?>
                   </div>
                </div>
            </div>	
		 <div class="col-sm-4">
                <div class="ibox">
                    <div class="ibox-content">
                        <h3><i class="fa fa-globe"></i> 开启的UDP端口</h3>
                  <?php
                    exec(" netstat -nap|grep udp|grep \"0 0.0.0.0:\"",$udp);
                     preg_match_all("/\:([0-9]*)/",implode("\n",$udp),$m);
                     foreach($m[1] as $v){ 
                     echo '<span class="label label-primary">'.$v.'</span> ';}?>
                       </div>
                    </div>
             </div>
		  </div>
		</div> 
      <div class="col-sm-6">
    <div class="row">
	    <div class="col-sm-12">
             <div class="ibox">
                    <div class="ibox-content">
                        <h3><i class="fa fa-won"></i> 服务器状态</h3>
                  <div class="row"> <p>
                <div class="col-sm-4">
             <div class="ibox">
              <div class="ibox-content">
			   <center>
				今昨使用状态
					<br>ToDay： <?php echo round($pallKB / 1073741824 * 100) / 100;?> GB
					  <br> YesterDay： <?php echo round($oallKB / 1073741824 * 100) / 100;?> GB
				    	</center>
						</div></div></div>				  
          <?php
          function array_space_del($arr){
			 foreach($arr as $key=>$vo){
				 if(trim($vo) != ""){
					 $b[] = $vo;
				 }
			 }
			 return $b;
		 }
     exec("ifconfig",$net);
		 foreach($net as $line){
			 if(trim($line)==""){
				$nets[] = $netinfo;
				$netinfo = array();
			 }else{
				$netinfo[] = $line;
			 }
		 }
		foreach($nets as $info){
			$t = explode(":",$info[0]);
			$netname = $t[0];
			
			foreach($info as $v){
				$t2 = explode(" ",$v);
				$t2 = array_space_del($t2);
				//var_dump($t2);
				switch($t2[0]){
					case $netname.":":
						$net_mtu = $t2[3];
					break;
					
					case "inet":
						$net_ip = $t2[1];
					break;
					
					case "RX":
						if($t2[1] == "packets"){
							$net_recv = $t2[4];
						}
					break;
					
					case "TX":
						if($t2[1] == "packets"){
							$net_sent = $t2[4];
						}
					break;
				}
			}
    if($net_sent >= 1073741824) {
    $TX = round($net_sent / 1073741824 * 100) / 100 . ' GB';
    } elseif($net_sent >= 1048576) {
    $TX = round($net_sent / 1048576 * 100) / 100 . ' MB';
    } elseif($net_sent >= 1024) {
    $TX = round($net_sent / 1024 * 100) / 100 . ' KB';
    } else {
    $TX = $net_sent . ' Bytes';}
    if($net_recv >= 1073741824) {
    $RX = round($net_recv / 1073741824 * 100) / 100 . ' GB';
    } elseif($net_recv >= 1048576) {
    $RX = round($net_recv / 1048576 * 100) / 100 . ' MB';
    } elseif($net_recv >= 1024) {
    $RX = round($net_recv / 1024 * 100) / 100 . ' KB';
    } else {
    $RX = $net_recv . ' Bytes';}
   echo '<div class="col-sm-4">
             <div class="ibox">
              <div class="ibox-content">
			  <center>
				<span class="label label-primary">',$netname,'</span> 网卡状态
					<br>接收流量：', $RX,
					  '<br>发送流量：', $TX,
						'</div></div></div></center>';
		}?>	
		</div></p>
		<p>PS：eth开头为服务器真实网卡，tun开头为Op创建的虚拟网卡，每次重启VPN虚拟网卡数据都会清零哦！</p>
		  </div>
                </div>
            </div>
		</div> 			
         </div>
				 <div class="col-sm-6">
				    <div class="ibox float-e-margins">
                        <div class="" id="ibox-content">

                            <div id="vertical-timeline" class="vertical-container">
								
								   <div class="vertical-timeline-block">
                                    <div class="vertical-timeline-icon navy-bg">
                                        <i class="fa fa-gears"></i>
                                    </div>

                                    <div class="vertical-timeline-content">
                                        <h2>检测更新</h2>
                                        <p>当前版本：解密版&nbsp;
										<?php
										echo "当前版本已是最新，无需更新。";
										$News='没事就想去博客逛~';
										$GW='http://blog.67cc.cn/';?>
                                        </p>
                                        <a href="<?php echo $GW;?>" target="_blank" class="btn btn-sm btn-primary"><?php echo $News;?></a>
                                        <span class="vertical-date">
                                     <small>检测时间 <?php echo date("Y年m月d日")?></small>
                                </span>
                                    </div>
                                </div>
                            </div>
                         </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js"></script>
    <!-- Flot -->
    <script src="../../assets/js/plugins/flot/jquery.flot.js"></script>
	<script src="../../assets/js/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.pie.js"></script>
    <!--flotdemo-->
<script type="text/javascript">
// 流量实时显示
function GetNet(){
	   $.post("GetNet.php?act=net",{},
	   function(data){
				$(".Netid").html(data);
			});
}
GetNet();
// 利用javascript定时器实时替换流量每秒的最新值
setInterval(GetNet,5000);
</script>
<script type="text/javascript">

$(function() {
// 流量使用信息折线图
             var container = $("#flot-line-chart-moving");
             var maximum = 10 / 2 || 30;
             series = [{
                data: [
				   [<?php echo $data1;?>, <?php echo $a[0];?>],
				   [<?php echo $data2;?>, <?php echo $a[1];?>],
				   [<?php echo $data3;?>, <?php echo $a[2];?>],
				   [<?php echo $data4;?>, <?php echo $a[3];?>],
				   [<?php echo $data5;?>, <?php echo $a[4];?>],
				   [<?php echo $data6;?>, <?php echo $a[5];?>],
				   [<?php echo $data7;?>, <?php echo $a[6];?>],
				   [<?php echo $data8;?>, <?php echo $a[7];?>],
				   [<?php echo $data9;?>, <?php echo $a[8];?>],
				   [<?php echo $data10;?>, <?php echo $a[9];?>],
				   [<?php echo $data11;?>, <?php echo $a[10];?>],
				   [<?php echo $data12;?>, <?php echo $a[11];?>],
				],
                lines: {
                    show: true
                },
				points: { 
				    show: true 
				}
            }];
            var plot = $.plot(container, series, {
                grid: {
                    color: "#999999",
                    tickColor: "#f7f9fb",
                    borderWidth:0,
                    minBorderMargin: 20,
                    labelMargin: 10,
                    backgroundColor: {
                        colors: ["#ffffff", "#ffffff"]
                    },
                    margin: {
                        top: 8,
                        bottom: 20,
                        left: 20
                    },
                },
                colors: ["#4fc5ea"],
                xaxis: {
					min: <?php echo $xxmin;?>,
                    max: <?php echo $xxmax;?>
                },
                yaxis: {
                    min: 0,
                    max: <?php echo floor($pos/100+1)*100;?>
                },
            });
        });
</script>
<script>
 // 圆形在线百分率
 $(document).ready(function () {		
            $("#sparkline6").sparkline([<?php echo sprintf("%.1f", $bfl_tcp);?>, <?php echo sprintf("%.1f", (100 - $bfl_tcp));?>], {
                type: 'pie',
                height: '120',
                sliceColors: ['#2E8B57', '#87CEFA']
            });
            $("#sparkline8").sparkline([<?php echo sprintf("%.1f", $bfl_udp);?>, <?php echo sprintf("%.1f", (100 - $bfl_udp));?>], {
                type: 'pie',
                height: '120',
                sliceColors: ['#2E8B57', '#87CEFA']
            });
        });
</script>
 </body>
</html>