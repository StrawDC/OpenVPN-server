<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>卡密管理 - 搜索卡密</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;width: 100%">
<section class="panel panel-default">
  <div class="ibox-title">
                        <h5>卡密管理 >><small>搜索卡密</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>

	       <div class="panel-body">
        <div class="panel-body">
          <form action="./kms_list.php?my=cahx" method="GET" class="form-inline" role="form">
            <div class="form-group">
              <label>类别</label>
              <select name="type" class="form-control">
                <option value="1">用户卡密</option>
              </select>
            </div>
            <div class="form-group">
              <label>内容</label>
              <input type="text" name="cha" value="" class="form-control" required/>
            </div>
            <input type="submit" value="查询" class="btn btn-primary"/>
          </form>
        </div>
      </div>					
            </section>
			  </div>
                        </div>
                    </div>
                </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>


    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    </body>
</html>
