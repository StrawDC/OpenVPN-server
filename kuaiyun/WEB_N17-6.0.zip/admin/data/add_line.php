<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>线路管理 - 添加线路</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> <link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="../../assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>线路管理 >><small>添加线路</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="form_basic.html#">
                              </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
<?php
if ($_POST['content']) {
echo '
<div class="panel-heading w h"><h3 class="panel-title">添加线路结果</h3></div>
<div class="panel-body box">';	
$name = daddslashes($_POST['name']);
$type = date("Y-m-d");
$label = daddslashes($_POST['sm']);
$group = daddslashes($_POST['group']);
$line = array(
'# 快云云免配置',
'# www.kuaiyum.com',
'# 欢迎加入快云线路分享群:642989706',
'setenv IV_GUI_VER "de.blinkt.openvpn 0.6.17"',
'machine-readable-output',
'client',
'dev tun',
'proto '.$_POST['xieyi'],
'connect-retry-max 5',
'connect-retry 5',
'resolv-retry 60',
'########免流代码########',
$_POST['content'],
'########免流代码########',
'resolv-retry infinite',
'nobind',
'persist-key',
'persist-tun',
'## 证书',
'<ca>',
'[C证书]',
'</ca>',
'key-direction 1',
'<tls-auth>',
'[T证书]',
'</tls-auth>',
'auth-user-pass',
'ns-cert-type server',
'comp-lzo',
'verb 3');
$content = implode("\n",$line);
$sql = "insert into `line` (`name`,`content`,`type`,`group`,`show`,`label`,`time`) values ('{$name}','{$content}','{$type}','{$group}',1,'{$label}','".time()."')";
if ($DB->query($sql)){ 
echo '<div class="box">恭喜亲，成功添加一条新线路</div>';
}else{
echo '<div class="box">奥，添加该线路失败,' . $DB->error() . '</div>';
}
echo '<hr/><a href="./add_line.php" class="btn btn-success">返回继续添加</a></div></div>';
exit;}?>    
                  <form action="./add_line.php" method="post" class="form-horizontal">
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">线路名称</label>

                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="name" required="required"/>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-error">
                                <label class="col-sm-2 control-label">线路说明</label>

                                <div class="col-sm-8">
                                   <input type="text" class="form-control" name="sm">
                                </div>
                            </div>
							
							 <div class="hr-line-dashed"></div>
                            <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">运营商选择</label>
                                <div class="col-sm-3">
                                    <select class="form-control m-b" name="group">
                                    <?php
                                   $rs=$DB->query("SELECT * FROM line_grop");
                                  while($res = $DB->fetch($rs))							
                                  echo '<option value="'.$res['id'].'">'.$res['name'].'</option>';
                                            ?>
                                    </select>
                                </div>
							 <label class="col-sm-2 control-label">线路协议</label>
								   <div class="col-sm-3 control-label">
                                    <select class="form-control m-b" name="xieyi">
									<option value="tcp">TCP</option>
									<option value="udp">UDP</option>
                                    </select>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
							<div class="form-group has-success">
                                 <label class="col-sm-2 control-label">免流代码</label>
                                 <div class="col-sm-8">
                                   <textarea class="form-control" placeholder="只要输入免流代码，IP请换成 [ip]" rows="10" name="content"></textarea>
                                 </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2"> 
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>	
    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    <!-- iCheck -->
    <script src="../../assets/js/plugins/iCheck/icheck.min.js"></script>

</body>

</html>
