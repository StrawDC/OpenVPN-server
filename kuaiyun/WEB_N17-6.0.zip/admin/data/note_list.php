<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>负载集群管理 - 节点列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../../asstes/favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;width: 100%">
<section class="panel panel-default">
  <div class="ibox-title">
                        <h5>负载集群管理 >><small>节点列表</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
<div class="panel-body">
				
<div class="form-group">
<?php
if($my=='del'){
echo '<div class="panel-heading w h"><h3 class="panel-title">删除节点结果</h3></div>
<div class="panel-body box">';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `ky_fz` WHERE id='$id'");
if($sql){echo '恭喜亲，删除节点成功';}
else{echo '噢，删除节点失败,请稍后重新尝试.！';}
echo '<hr/><a href="./note_list.php" class="btn btn-success">返回节点列表</a></div></div>';
}else{
$numrows=$DB->count("SELECT count(*) from `ky_fz` WHERE 1");
$sql=" 1";
echo '<form><a href="add_note.php" class="btn btn-primary">添加节点</a>
<a href="#" class="btn btn-info">平台共有 <b>'.$numrows.'</b> 个节点</a></form>';
?>
       <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead><tr><th class="text-center">排序ID</th><th class="text-center">名称</th><th class="text-center">地址</th><th class="text-center">TCP在线</th><th class="text-center">UDP在线</th><th class="text-center">满载人数</th><th class="text-center">描述</th><th class="text-center">添加时间</th><th class="text-center">管理操作</th></tr></thead>
           <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM `ky_fz` WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs)){
$ip = gethostbyname(''.$res['ipport'].'');
$all_udp=$DB->count("SELECT count(*) from `openvpn` WHERE online=1 && `last_ip`='{$ip}' && `xieyi`='udp'");
$all_tcp=$DB->count("SELECT count(*) from `openvpn` WHERE online=1 && `last_ip`='{$ip}' && `xieyi`='tcp-server'");	
?>
<tr>
<td class="text-center"><?=$res['order']?></td>
<td class="text-center"><?=$res['name']?></td>
<td class="text-center"><?=$res['ipport']?></td>
<td class="text-center"><?=$all_tcp?></td>
<td class="text-center"><?=$all_udp?></td>
<td class="text-center"><?=$res['maximum']?></td>
<td class="text-center"><?=$res['type']?></td>
<td class="text-center"><?=$res['time']?></td>
<td class="text-center"><a href="./online_list.php?ip=<?=$ip?>" class="btn btn-xs btn-success">查看</a>&nbsp;<a href="./note_set.php?&id=<?=$res['id']?>" class="btn btn-xs btn-info">编辑 </a>&nbsp;<a href="./note_list.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="note_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="note_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="note_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="note_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="note_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="note_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>

 
                  
              </div>
            </section>
			  </div>
                        </div>
                    </div>
                </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>


    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    </body>
</html>
