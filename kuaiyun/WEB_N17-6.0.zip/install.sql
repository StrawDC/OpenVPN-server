-- Adminer 4.2.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `auth_config`;
CREATE TABLE `auth_config` (
  `id` varchar(80) NOT NULL DEFAULT '1',
  `gg` text,
  `ggs` text,
  `dl1` float DEFAULT NULL COMMENT 'vip1',
  `dl2` float DEFAULT NULL COMMENT 'vip2',
  `dl3` float DEFAULT NULL COMMENT 'vip3',
  `dl4` float DEFAULT NULL COMMENT 'vip4',
  `dl5` float DEFAULT NULL COMMENT 'vip5',
  `dl0` float DEFAULT NULL COMMENT 'vip0',
  `dls1` float NOT NULL,
  `dls2` float NOT NULL,
  `dls3` float NOT NULL,
  `dls4` float NOT NULL,
  `dls5` float NOT NULL,
  `dls0` float NOT NULL,
  `regok` int(11) DEFAULT NULL,
  `activeok` int(11) DEFAULT NULL,
  `user_reg` int(11) DEFAULT NULL,
  `reg_cash` int(11) DEFAULT NULL,
  `reg_endtime` int(11) DEFAULT NULL,
  `user_reg_cash` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `auth_config` (`id`, `gg`, `ggs`, `dl1`, `dl2`, `dl3`, `dl4`, `dl5`, `dl0`, `dls1`, `dls2`, `dls3`, `dls4`, `dls5`, `dls0`, `regok`, `activeok`, `user_reg`, `reg_cash`, `reg_endtime`, `user_reg_cash`) VALUES
('1',	'尊敬的代理您好，为了更加优质的用户体验，我们对流控系统进行了升级。流控已经换成自家编写的系统，更能保护用户隐私并且提供更加完善的服务器，感谢您的理解和支持。',	'尊敬的用户您好，为了更加优质的用户体验，我们对流控系统进行了升级。流控已经换成自家编写的系统，更能保护用户隐私并且提供更加完善的服务器，感谢您的理解和支持。',	999,	999,	999,	999,	0,	999,	999,	999,	999,	999,	0,	999,	0,	0,	1,	500,	1,	200);

DROP TABLE IF EXISTS `auth_daili`;
CREATE TABLE `auth_daili` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PayUser` tinytext NOT NULL,
  `PayKey` tinytext NOT NULL,
  `qq` tinytext,
  `html` tinytext,
  `name` tinytext,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `vip` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `auth_daili` (`id`, `PayUser`, `PayKey`, `qq`, `html`, `name`, `user`, `pass`, `rmb`, `vip`, `active`, `regdate`) VALUES
(1,	'',	'',	'1797106720',	NULL,	NULL,	'kyun',	'kyun',	999.00,	5,	1,	'2012-07-00 00:01:00');

DROP TABLE IF EXISTS `auth_kms`;
CREATE TABLE `auth_kms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` tinyint(1) NOT NULL DEFAULT '1',
  `daili` int(11) NOT NULL DEFAULT '0',
  `km` varchar(64) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `values` decimal(11,2) DEFAULT NULL,
  `money` decimal(11,2) DEFAULT '0.00',
  `isuse` tinyint(1) DEFAULT '0',
  `user` varchar(50) DEFAULT NULL,
  `usetime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `km` (`km`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `auth_kms` (`id`, `kind`, `daili`, `km`, `value`, `values`, `money`, `isuse`, `user`, `usetime`, `addtime`) VALUES
(1,	1,	0,	'511920695403012691',	99,	99.00,	0.00,	0,	NULL,	NULL,	'2017-09-02 17:22:19'),
(2,	2,	0,	'870305764933510531',	99,	NULL,	0.00,	0,	NULL,	NULL,	'2017-09-02 17:22:32');

DROP TABLE IF EXISTS `auth_log`;
CREATE TABLE `auth_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `kyun`;
CREATE TABLE `kyun` (
  `logo` text COMMENT 'www.kuaiyum.com',
  `logo2` text COMMENT 'www.kuaiyum.com',
  `zhifu` tinytext CHARACTER SET latin1 COMMENT 'www.kuaiyum.com',
  `qun` tinytext CHARACTER SET latin1 COMMENT 'www.kuaiyum.com',
  `fyue` tinytext CHARACTER SET latin1 COMMENT 'www.kuaiyum.com',
  `qq` tinytext COMMENT 'www.kuaiyum.com',
  `gw` tinytext CHARACTER SET latin1 COMMENT 'www.kuaiyum.com',
  `app` tinytext CHARACTER SET latin1 COMMENT 'www.kuaiyum.com',
  `html` tinytext COMMENT 'www.kuaiyum.com',
  `name` tinytext COMMENT 'www.kuaiyum.com',
  `versionCode` tinytext COMMENT 'www.kuaiyum.com',
  `url` tinytext COMMENT 'www.kuaiyum.com',
  `content` tinytext COMMENT 'www.kuaiyum.com',
  `splash` tinytext COMMENT 'www.kuaiyum.com',
  `splashurl` tinytext COMMENT '快云免流版权所有'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `kyun` (`logo`, `logo2`, `zhifu`, `qun`, `fyue`, `qq`, `gw`, `app`, `html`, `name`, `versionCode`, `url`, `content`, `splash`, `splashurl`) VALUES
('网站名称',	'http://hunan.kuaiyum.com:8888/assets/img/logo.png',	'http://youka.la',	'http://shang.qq.com/wpa/qunwpa?idkey=9bfe1754d85068752e0507341a2ff6c3aa7a7914f9ae1d88e1d5d55ce6bccad4',	'https://shang.qq.com/wpa/qunwpa?idkey=70d4b9eb2d742127f48ef5acccdc9607fd5dfebaf764e1069f765e713ca9afbe',	'QQ客服',	'http://hunan.kuaiyum.com',	'http://hunan.kuaiyum.com:8888/user/app',	'亲，有什么问题欢迎联系我们的客服哦！',	'网站名称客服',	'100',	'http://kuaiyum.com/kyun.apk',	'软件有更新快升级吧!',	'no',	'http://kuaiyum.com/Splash.png');

DROP TABLE IF EXISTS `ky_buy`;
CREATE TABLE `ky_buy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trade` text NOT NULL,
  `i` int(2) NOT NULL,
  `tc` text NOT NULL,
  `money` text NOT NULL,
  `user` text NOT NULL,
  `dlid` int(11) NOT NULL DEFAULT '0',
  `time` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `ky_fk`;
CREATE TABLE `ky_fk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` text COLLATE utf8_estonian_ci NOT NULL,
  `diqu` text COLLATE utf8_estonian_ci NOT NULL,
  `lid` int(11) NOT NULL,
  `wang` int(1) NOT NULL,
  `time` text COLLATE utf8_estonian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;


DROP TABLE IF EXISTS `ky_fz`;
CREATE TABLE `ky_fz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `ipport` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` tinytext NOT NULL,
  `maximum` int(11) DEFAULT '200',
  `order` int(11) DEFAULT '1',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `ky_fz` (`id`, `name`, `ipport`, `time`, `type`, `maximum`, `order`) VALUES
(1,	'默认节点',	'hunan.kuaiyum.com',	'2017-10-16 08:08:20',	'玩游戏/看视频/下软件',	200,	1);

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `ky_gg`;
CREATE TABLE `ky_gg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `dlid` text NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`),
  KEY `id_3` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ky_gg` (`id`, `name`, `content`, `dlid`, `time`) VALUES
(1,	'欢迎各位用户使用快云免流！',	'本公告仅仅是测试，请管理员自行删除！',	'0',	'1504345226');

DROP TABLE IF EXISTS `ky_gl`;
CREATE TABLE `ky_gl` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;

INSERT INTO `ky_gl` (`id`, `username`, `password`) VALUES
(1,	'MD5账号',	'MD5密码');

DROP TABLE IF EXISTS `ky_pay`;
CREATE TABLE `ky_pay` (
  `id` int(11) NOT NULL,
  `user` text NOT NULL,
  `key` text NOT NULL COMMENT '快云版权所有',
  `url` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `ky_pay` (`id`, `user`, `key`, `url`) VALUES
(1,	'请到www.kypay.top申请账号',	'请到www.kypay.top申请KEY',	'http://hunan.kuaiyum.com:8888/Kyws/mode/pay/return_url.php');

DROP TABLE IF EXISTS `ky_tc`;
CREATE TABLE `ky_tc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `G` int(11) NOT NULL,
  `tian` int(11) NOT NULL,
  `money` text NOT NULL COMMENT '快云版权所有',
  `dlid` int(11) NOT NULL DEFAULT '0',
  `i` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `ky_tc` (`id`, `name`, `G`, `tian`, `money`, `dlid`, `i`) VALUES
(1,	'30天 无限流量',	9999,	30,	'8',	0,	1),
(2,	'15天 无限流量',	9999,	15,	'6',	0,	1),
(3,	'7天 无限流量',	9999,	7,	'4',	0,	1),
(4,	'30天 15G流量包',	15,	30,	'6',	0,	2),
(5,	'30天 6G流量包',	6,	30,	'4',	0,	2),
(6,	'30天 1G流量包',	1,	30,	'2',	0,	2);

DROP TABLE IF EXISTS `ky_yd`;
CREATE TABLE `ky_yd` (
  `id` int(11) NOT NULL,
  `username` tinytext NOT NULL,
  `readid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `ky_zs`;
CREATE TABLE `ky_zs` (
  `ca` text COLLATE utf8_estonian_ci NOT NULL,
  `tls` text COLLATE utf8_estonian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;

INSERT INTO `ky_zs` (`ca`, `tls`) VALUES
('-----BEGIN CERTIFICATE-----\r\nMIIE2TCCA8GgAwIBAgIJAKhG9gxAGKRhMA0GCSqGSIb3DQEBCwUAMIGjMQswCQYD\r\nVQQGEwJDTjEOMAwGA1UECBMFSHVOYW4xETAPBgNVBAcTCEhlbmdZYW5nMRQwEgYD\r\nVQQKEwtrdWFpeXVtLmNvbTEPMA0GA1UECxMGaVBob25lMRcwFQYDVQQDEw5rdWFp\r\neXVtLmNvbSBDQTEQMA4GA1UEKRMHT3BlblZQTjEfMB0GCSqGSIb3DQEJARYQS3l1\r\nbkBrdWFpeXVtLmNvbTAeFw0xNzA4MjYwNjIzNTdaFw0yNzA4MjQwNjIzNTdaMIGj\r\nMQswCQYDVQQGEwJDTjEOMAwGA1UECBMFSHVOYW4xETAPBgNVBAcTCEhlbmdZYW5n\r\nMRQwEgYDVQQKEwtrdWFpeXVtLmNvbTEPMA0GA1UECxMGaVBob25lMRcwFQYDVQQD\r\nEw5rdWFpeXVtLmNvbSBDQTEQMA4GA1UEKRMHT3BlblZQTjEfMB0GCSqGSIb3DQEJ\r\nARYQS3l1bkBrdWFpeXVtLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC\r\nggEBALbGp0YmSLZyNtAtkg6kAZg2+6aLSya5VUYpc/KGYlfJU7BlFzLnr1xZh2RQ\r\nYntGOTl7l2lzDgirWfrYbVK+Cda5BDQ2FKcPro2+8Q0oB14KPkvkoadsCWsyq6Qq\r\nJQygEllnL2AYGU2oTgUbxPVpEEb2qo1B245DBS8eSL4CeJAbA474XPPinEeITqG2\r\nflQsiMfnmgwXZw7REq65pDxGCurfZnOzd8/iYquYpZRkzCGkLZMcLTy2tWIWs1mT\r\nw37B0PsjPrMIR4eEMYitbrcqKIZzhPzFxFnCOebNmzSkiYbCcxKtw3wtf0ny/95r\r\nvR1lPgiwHmhI1bW5OgrlApotz70CAwEAAaOCAQwwggEIMB0GA1UdDgQWBBQ0Qm+H\r\nVzYrrCZ9brJ3Xth1Nuw20zCB2AYDVR0jBIHQMIHNgBQ0Qm+HVzYrrCZ9brJ3Xth1\r\nNuw206GBqaSBpjCBozELMAkGA1UEBhMCQ04xDjAMBgNVBAgTBUh1TmFuMREwDwYD\r\nVQQHEwhIZW5nWWFuZzEUMBIGA1UEChMLa3VhaXl1bS5jb20xDzANBgNVBAsTBmlQ\r\naG9uZTEXMBUGA1UEAxMOa3VhaXl1bS5jb20gQ0ExEDAOBgNVBCkTB09wZW5WUE4x\r\nHzAdBgkqhkiG9w0BCQEWEEt5dW5Aa3VhaXl1bS5jb22CCQCoRvYMQBikYTAMBgNV\r\nHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQCmJj795uLgVjedUII2EO9Gqdnc\r\nRs/0IeCHYzX+uPSbjo145FnciKGEWWnJAxIlrnk4x88/4uD0ARLPN66kbxiNkV1l\r\nCibn6h28hMQXwNNoXz7Cdcmpv/1yQeAhDB7I+Br7TL77pbttgrEVmPcPiasqUfVD\r\nxKZjwTBf0I8TZvurMsIy2rg844bZW4ZapKkZs1ZPvFfyyzEjzHbrn4LRBnaHoMbU\r\nKzlAZgBqg8ier3GCpCPYv/sIbqGFd6rYmqU5OoMNmp1cc85SOGqX1dGKDlcnvQY5\r\n6Xprlq8Vy0jhrb+aplgc95X4dMSeo5r2XsHlM4sEywWrUQCDhEhFVVWvdFwv\r\n-----END CERTIFICATE-----',	'-----BEGIN OpenVPN Static key V1-----\r\nf875e8784a633bdc22c553afe8410514\r\n926eff4ff1cc5cf96a9e05578e2d0f54\r\nb6876eaf3d9e16ea25835087f47788ee\r\nec7ad59f91adb411cb8c0b405ea766aa\r\n9b12a82dc0b023130e486b4ae1f34cd0\r\n188cf695c77fa60b6578eb91aa421f22\r\n9d5cce4bdc800c6f662e2161b60c4773\r\n162dbd169a36f25d7932e3cff0224758\r\ndfabcffb26dc2c2a26a1d7056b3f8e93\r\nd1e128f2fd3b5d26b4379203c2484d7c\r\n3e72ee7dca6b3ba7ed85387f82d12bb4\r\n20c1b933b65449a42002c994c4d2ef18\r\n131a4aa02d6dcb24389879cf5b820c98\r\n113a76bab0e6cb0b91275a9f1b8b33d8\r\n8c7a4ab3ae08c365476055290980d409\r\nef16b0475f301ae2b45bd0dacbbf964b\r\n-----END OpenVPN Static key V1-----');

DROP TABLE IF EXISTS `line_grop`;
CREATE TABLE `line_grop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_bin NOT NULL,
  `show` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `line_grop` (`id`, `name`, `show`, `order`) VALUES
(1,	'中国移动',	1,	1),
(2,	'中国电信',	1,	1),
(3,	'中国联通',	1,	1),
(4,	'三网通用',	1,	1);

DROP TABLE IF EXISTS `openvpn`;
CREATE TABLE `openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(128) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` int(18) NOT NULL,
  `endtime` int(18) NOT NULL DEFAULT '0',
  `mail` text CHARACTER SET utf8,
  `dlid` int(11) NOT NULL DEFAULT '0',
  `tj_u` int(11) NOT NULL DEFAULT '0',
  `online` int(11) NOT NULL DEFAULT '0',
  `last_ip` tinytext CHARACTER SET utf8 NOT NULL,
  `area` tinytext CHARACTER SET utf8 NOT NULL,
  `isp` tinytext CHARACTER SET utf8 NOT NULL,
  `client` tinytext CHARACTER SET utf8 NOT NULL,
  `remote_port` int(11) NOT NULL,
  `xieyi` tinytext NOT NULL,
  `login_time` int(18) NOT NULL,
  `line_id` int(18) NOT NULL,
  `tian` int(11) NOT NULL DEFAULT '0' COMMENT 'www.kuaiyum.com',
  PRIMARY KEY (`id`),
  UNIQUE KEY `iuser` (`iuser`),
  KEY `tian` (`tian`),
  KEY `id` (`id`),
  KEY `tian_2` (`tian`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

INSERT INTO `openvpn` (`id`, `iuser`, `isent`, `irecv`, `maxll`, `pass`, `i`, `starttime`, `endtime`, `mail`, `dlid`, `tj_u`, `online`, `last_ip`, `area`, `isp`, `client`, `remote_port`, `xieyi`, `login_time`, `line_id`, `tian`) VALUES
(1,	'1797106720',	0,	0,	10736344498176,	'123456',	1,	1501141999,	1601141999,	'fyuewl@qq.com',	0,	10,	0,	'119.39.248.32',	'湖南省',	'联通',	'OPPO',	68,	'udp',	1501141999,	0,	999);

DROP TABLE IF EXISTS `top`;
CREATE TABLE `top` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `data` bigint(20) NOT NULL,
  `time` text NOT NULL,
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2017-10-22 07:19:24