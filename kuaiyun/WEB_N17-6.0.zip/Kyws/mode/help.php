<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../Data/api.inc.php");
if($_GET['dlapp']){
$res = $DB->get_row("select * from `auth_daili` where id='{$_GET['dlapp']}'");	
}else{
$res = $DB->get_row("select * from `kyun` limit 1");}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="/Core/fun/prettify.css"/>
<div class="main">
	<div class="panel panel-default">
   <div class="panel-body">
    <?php echo $res['html'];
	  echo '<br><br><a href="mqqwpa://im/chat?chat_type=wpa&uin='.$res['qq'].'&version=1&src_type=web&web_src=oicqzone.com" style="margin-top:10px;"><img src="images/qq.png" style="width:20px;float:left;">&nbsp;'.$res[name].'</a><br><br>';
?>
   </div>
</div>
</div>

