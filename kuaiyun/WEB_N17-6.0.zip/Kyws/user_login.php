<?php
require('system.php');
$db_host = _host_; //数据库地址
$db_user = _user_; //数据库用户
$db_pass = _pass_; //数据库密码
$db_port = _port_; //数据库端口
$db_data = _ov_; //数据库名称

function addslashesi($str){
	$tmp = explode(" ",$str);
	if(count($tmp)>1){
		die("Access die");//包含空格直接禁止登陆
	}

	$tmp2 = explode(";",$str);
	if(count($tmp2)>1){
		die("Access die");
	}

	$str = html_encode($str); //为特殊符号添加转义符号
	return $str;
}
$parm = $argv;
$username = addslashesi($parm[1]);
$password = addslashesi($parm[2]);
$remote_port = addslashesi($parm[3]);
$last_ip = addslashesi($parm[4]);
$xieyi = addslashesi($parm[5]);

$nums = count($parm);
if($nums != 6){
	die("error parms"); //用户名或者密码为空时 禁止登录
}

if(trim($username) == "" || trim($password) == "")
{
	die("error parms"); //用户名或者密码为空时 禁止登录
}
	$db = db("openvpn");
	$info = $db->where("binary `iuser`=:username AND `pass`=:password AND irecv+isent < maxll",[":username"=>$username,":password"=>$password])->find();
	if($info){
		if($info["i"] == '2')
		{
		   $endtime = time()+3600*24*$info['tian'];
		   $db->where(array('iuser'=>$username))->update(array('i'=>'1','starttime'=>time(),'endtime'=>$endtime));
		}
		if($info["endtime"] < time())
		{
			goto ERROR;
		}
		if($info["i"] == 1){
			goto SUCCESS;
		}else{
			goto ERROR;
		}
		
	}
	else
	{
		goto ERROR;
	}
SUCCESS:
	$db->where(["iuser"=>$info["iuser"]])->update(["online"=>'1',"last_ip"=>$last_ip,"login_time"=>time(),"remote_port"=>$remote_port,"xieyi"=>$xieyi]);
	die("success");
exit;
ERROR:
exit;