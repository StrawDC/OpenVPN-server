<?php 
header('Content-Type: text/html; charset=UTF-8');
?><html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta charset="utf-8"> 
<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<title>好友推荐注册地址</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>
<body>
<?php

	//上次发送时间
	$system_time = time();
	$last_time = $_SESSION["last_send"] == "" ? 0 : $_SESSION["last_send"];
	$al_time = $system_time - $last_time;
?>
<style>
.main{
	background:#fff;
	padding:15px;
	border-right:1px solid #ccc;
	border-bottom:1px solid #ccc;
	border-top:1px solid #dfdfdf;
	border-left:1px solid #dfdfdf;
}
</style>

<div class="main">
<div style="height:50px"></div>
     <div class="form-group"> 
        <label for="name"><span class="glyphicon glyphicon-user"></span>&nbsp;用户名</label> 
        <input type="text" class="form-control" id="name" placeholder="请输入您要注册的账号"> 
    </div> 
	
	<div class="form-group"> 
        <label for="name"><span class="glyphicon glyphicon-lock"></span>&nbsp;密码</label> 
        <input type="password" class="form-control" id="pass" placeholder="请输入密码"> 
    </div>
	<div class="form-group"> 
        <label for="mail"><span class="glyphicon glyphicon-user"></span>&nbsp;邮箱号码</label> 
        <input type="email" class="form-control" id="mail" placeholder="请输入你的邮箱获取验证码"/>
    </div>
	<div class="form-group"> 
        
        <div style="float:left;width:150px"><input type="text" class="form-control" id="code" placeholder="请输入验证码"></div>
		<div class=" col-sm-4;width:40%;" style="float:right"><button type="button" class="btn btn-primary sms" onclick="sms()" >获取验证码</button> </div>
		<div style="clear:both"></div>
	</div> 
    <button type="submit" class="btn btn-success btn-block" onclick="reg()" >注册</button> <br>
</div>

<script>
<?php
	if($al_time > 60){
		echo "var t = 60;
var allow = true;";
	}else{
		$ac = 60 - $al_time;
		echo "var t = ".$ac.";
var allow = false;
alert(\"骚等\"+t+\"秒哦\");
jsq();
";
	}
$code = rand(10000,99999);
$yzm = $code;
?>
  
function sms(){
	if($("#mail").val() == ""|| $("#name").val() == ""|| $("#pass").val() == ""){
		alert("任何一项均不能为空！");
		return;
	}
	if($("#mail").val() == ""){
		alert("你的邮箱号码忘记写喽！");
		return;
	}
	
	 var reg =/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;//正则表达式         
	if (!reg.test($("#mail").val())) {                   
		 alert("邮箱格式错误，请重新输入！");                         
		 return;  
    }  
	if(allow){
			allow = false;
		$('.sms').html('发送中...');
		
		$.get(
			'../mode/functions.php',{
				"u":$("#name").val(),
				"q":$("#mail").val(),
				"code":<?php echo $yzm;?>
			},function(data){
				if(data.status == "success"){
					$('.sms').html('60s后重新获取');
					jsq();
				}else{
					$('.sms').html("获取验证码");
					allow = true;
					alert(data.msg);
				}
			
			},"JSON"
		);
		}else{
			alert("骚等"+t+"秒哦");
		}
}
function jsq(){
	setTimeout(function(){
		t--;
		$('.sms').html(""+t+'s后重新获取');
		if(t != 0){
			jsq();
		}else{
			allow = true;
			t=60;
			$('.sms').html("获取验证码");
		}
	},1000);
}
function reg(){
	if($("#name").val() == ""|| $("#pass").val() == "" || $("#mail").val() == ""){
		alert("任何一项均不能为空");
	}if($("#code").val() != "<?php echo $yzm;?>"){
		alert("验证码输入错误！");
	}else{
		$.post(
			'../api.php?act=reg_in',{
				"username":$("#name").val(),
				"password":$("#pass").val(),
				"mail":$("#mail").val(),
				"tj_user":<?php echo $_GET['user'];?>
			},function(data){
				if(data.status == "success"){
					window.location.href="success.php";
				}else{
					alert(data.msg);
				}
			},"JSON"
		)
	}
}
function sysC(){
	window.myObj.colsePage();
}
$(function() { 
        $('#myModal').modal({ 
            keyboard: true 
        }) 
    }); 
</script>