<?php
header("Content-Type:text/html;charset=utf-8");
?>
<meta http-equiv="Refresh" content="3;url=/index.php" />
网页不存在，即将跳转到首页