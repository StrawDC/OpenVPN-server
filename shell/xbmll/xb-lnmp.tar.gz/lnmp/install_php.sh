#!/bin/bash

cur_dir=/root/lnmp
echo "-----小白免流™三分钟极速lnmp------"
echo "--------by:小白免流----------"
echo
echo "即将开始安装..."
 mkdir -p /home/wwwroot/default
 mkdir -p /home/wwwlog/
 
# 安装ngixn
rpm -ivh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm --force --nodeps
yum -y install nginx
mv /usr/share/nginx /home/wwwroot
rm -rf /etc/nginx/conf.d/default.conf
cp -r ${cur_dir}/conf/default.conf /etc/nginx/conf.d/default.conf
cd ${cur_dir}/conf/
chmod 777 nginx
./nginx
systemctl enable nginx.service
systemctl start nginx.service

# 配置epel源
rpm -ivh http://dl.fedoraproject.org/pub/epel/7/x86_64/e/epel-release-7-8.noarch.rpm --force
rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-7

# 配置remi源
rpm -Uvh http://rpms.famillecollet.com/enterprise/remi-release-7.rpm --force
rpm --import http://rpms.famillecollet.com/RPM-GPG-KEY-remi

# 安装php
yum -y --enablerepo=epel,remi,remi-php55 install php-fpm php-cli php-gd php-mbstring php-mcrypt php-mysqlnd php-opcache php-pdo php-devel php-xml
sed -i 's/;date.timezone =/date.timezone = PRC/g' /etc/php.ini
sed -i 's,listen = 127.0.0.1:9000,listen = /var/run/php-fpm/php5-fpm.sock,g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.owner = nobody/listen.owner = nginx/g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.group = nobody/listen.group = nginx/g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.mode = 0660/listen.mode = 0660/g' /etc/php-fpm.d/www.conf
systemctl enable php-fpm.service
systemctl start php-fpm.service

#xbmll.cn
curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
composer config -g repo.packagist composer https://packagist.phpcomposer.com

# 安装mysql
yum install -y mariadb mariadb-server
systemctl restart mariadb.service
systemctl enable mariadb.service

# 安装phpmyadmin
cd /root/
curl -O http://kangml-10046394.file.myqcloud.com/phpMyAdmin-4.6.2-all-languages.tar.gz
tar -zxvf phpMyAdmin-4.6.2-all-languages.tar.gz -C /home/wwwroot/default/
rm -f phpMyAdmin-4.6.2-all-languages.tar.gz 
