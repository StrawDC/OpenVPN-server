<?php
/**
 * 管理中心
**/
$mod='blank';
include("../api.inc.php");
$title='管理中心';

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
    if(!$rs){
        echo "此服务器不存在";
    }else{
        $file = 'http://'.$rs['ipport'].'/res/openvpn-status.txt';
		$file1 = 'http://'.$rs['ipport'].'/udp1/openvpn-status2.txt';
		$file2 = 'http://'.$rs['ipport'].'/udp2/openvpn-status3.txt';
    }
}else{
    $file = '../res/openvpn-status.txt';
	$file1 = '../udp1/openvpn-status2.txt';
	$file2 = '../udp2/openvpn-status3.txt';
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body  page-fade">
<?php include 'nav.php';?>



		

		
		
		<div class="row">
			<div class="col-sm-3 col-xs-6">
		
				<div class="tile-stats tile-red">
					<div class="icon"><i class="entypo-users"></i></div>
					<div class="num" data-start="0" data-end="<?php echo $countdaili?>" data-postfix="" data-duration="1500" data-delay="0">0</div>
		
					<h3>已注册代理数量</h3>
					<p><?php echo $countdaili2?>个代理未激活</p>
				</div>
		
			</div>
		
			<div class="col-sm-3 col-xs-6">
		
				<div class="tile-stats tile-green">
					<div class="icon"><i class="entypo-chart-bar"></i></div>
					<div class="num" data-start="0" data-end="<?php echo $countkm?>" data-postfix="" data-duration="1500" data-delay="600">0</div>
		
					<h3>已生成卡密数量</h3>
					<p><?php echo $countkm2?>个卡密未使用</p>
				</div>
		
			</div>
		
			<div class="col-sm-3 col-xs-6">
		
				<div class="tile-stats tile-aqua">
					<div class="icon"><i class="entypo-mail"></i></div>
					<div class="num" data-start="0" data-end="<?php echo $count?>" data-postfix="" data-duration="1500" data-delay="1200">0</div>
		
					<h3>注册用户数量</h3>
					<p><?php echo $count2?>个正常账号</p>
				</div>
		
			</div>
		
			<div class="col-sm-3 col-xs-6">
		
				<div class="tile-stats tile-blue">
					<div class="icon"><i class="entypo-rss"></i></div>
					<div class="num" data-start="0" data-end="<?php //echo $DB->
                                            //在线人数接口
                                            $str=file_get_contents('../res/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
											$str2=file_get_contents('../udp1/openvpn-status2.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
											$str3=file_get_contents('../udp2/openvpn-status3.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                            echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2)+(int)((substr_count($str2,date('Y'))-1)/2)+(int)((substr_count($str3,date('Y'))-1)/2);
                                            ?>" data-postfix="" data-duration="1500" data-delay="1800">0</div>
		
					<h3>在线人数数量</h3>
					<p>当前实时在线人数</p>
				</div>
		
			</div>
		</div>
		
		<br />
		
		
		


            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">当前平台实时流量监控日志</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

                    <?php
                    $myfile = fopen("../../../jiankong.log", "r") or die("Unable to open file!");
                    echo fread($myfile,filesize("../../../jiankong.log"));
                    fclose($myfile);
                    ?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>

		
		<!-- Footer -->
		<footer class="main">
			
			&copy; 2016 <strong></strong>  by <a href="http://www.dnsml.top" target="_blank">小白免流™</a>
		
		</footer>
	</div>

		

            <?php include("../copy.php");?>	



