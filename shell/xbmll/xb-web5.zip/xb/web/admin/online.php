<?php
$mod='blank';
include("../api.inc.php");
$title='当前在线用户';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
    if(!$rs){
        echo "此服务器不存在";
    }else{
        $file = 'http://'.$rs['ipport'].'/res/openvpn-status.txt';
		$file1 = 'http://'.$rs['ipport'].'/udp1/openvpn-status2.txt';
		$file2 = 'http://'.$rs['ipport'].'/udp2/openvpn-status3.txt';
    }
}else{
    $file = '../res/openvpn-status.txt';
	$file1 = '../udp1/openvpn-status2.txt';
	$file2 = '../udp2/openvpn-status3.txt';
}

?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body  page-fade">
        <?php include 'nav.php';?>
             <!-- Page Content -->
            <div class="page-content">
                <!-- Page Breadcrumb -->
                <div class="page-breadcrumbs">
                    <ul class="breadcrumb">
                        <li>
                            <i class="fa fa-home"></i>
                            <a href="#">平台首页</a>
                        </li>
                        <li class="active"><?php echo $title ?></li>
                    </ul>
                </div>
                <!-- /Page Breadcrumb -->
                 <!-- Page Header -->
                <div class="page-header position-relative">
                    <div class="header-title">
                        <h1>
                            <?php echo $title ?>
                        </h1>
                    </div>
                    <!--Header Buttons-->
                    <div class="header-buttons">
                        <a class="sidebar-toggler" href="#">
                            <i class="fa fa-arrows-h"></i>
                        </a>
                        <a class="refresh" id="refresh-toggler" href="">
                            <i class="glyphicon glyphicon-refresh"></i>
                        </a>
                        <a class="fullscreen" id="fullscreen-toggler" href="#">
                            <i class="glyphicon glyphicon-fullscreen"></i>
                        </a>
                    </div>
                    <!--Header Buttons End-->
                </div>
                <!-- /Page Header -->    
                <!-- Page Body -->
                <div class="page-body">
                    <h5 class="row-title"><i class="typcn typcn-th-small"></i>平台日志</h5>
                    <div class="row">
                        <div class="col-xs-12 col-md-12">
                            <div class="widget">
                                <div class="widget-header  with-footer">
                                    <span class="widget-caption">当前TCP <?php //echo $DB->
                                            //在线人数接口
                                            $str=file_get_contents('../res/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                            echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                                            ?> 人在线 ： 当前UDP <?php //echo $DB->
                                            //在线人数接口
                                            $str=file_get_contents('../udp1/openvpn-status2.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                            $str1=file_get_contents('../udp2/openvpn-status3.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
											echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2)+(int)((substr_count($str1,date('Y'))-1)/2)+(int)((substr_count($str2,date('Y'))-1)/2);
                                            ?> 人在线</span>
                                    <div class="widget-buttons">
                                        <a href="#" data-toggle="maximize">
                                            <i class="fa fa-expand"></i>
                                        </a>
                                        <a href="#" data-toggle="collapse">
                                            <i class="fa fa-minus"></i>
                                        </a>
                                        <a href="#" data-toggle="dispose">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="widget-body">
                                    <div class="alert alert-info fade in alert-radius-bordered alert-shadowed">
                                        <button class="close" data-dismiss="alert">
                                            ×
                                        </button>
                                        <i class="fa-fw fa fa-info"></i>

                                        <strong>请注意:</strong> 平台在线用户使用详细，刷新速度为你搭建时设置的时段
                                    </div>

                    <div class="panel-body">


                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                                <th>ID</th>
                                                <th data-priority="1">用户名</th>
                                                <th data-priority="3">上传</th>
                                                <th data-priority="6">下载</th>
                                          </tr>
                                      </thead>
                                      <tbody>
									  <br>
                                            <?php
                                            $str=file_get_contents($file);
                                            $num=(substr_count($str,date('Y'))-1)/2;
                                            $fp=fopen($file,"r");
                                            fgets($fp);
                                            fgets($fp);
                                            fgets($fp);
                                            for($i=0;$i<$num;$i++){
                                            $j=$i+1;
                                            echo "<tr>";
                                                $line=fgets($fp);
                                                $arr=explode(",",$line);
                                                $recv=round($arr[2]/1024)/1000;
                                                $sent=round($arr[3]/1024)/1000;
                                                echo "<th>".$j."</th>";
                                            echo "<td>TCP模式：".$arr[0]."</td>";
                                            echo "<td>".$recv."MB</td>";
                                            echo "<td>".$sent."MB</td>";
                                            echo "</tr>";
                                            }
                                            ?>

									  <br>
                                            <?php
                                            $str=file_get_contents($file1);
                                            $num=(substr_count($str,date('Y'))-1)/2;
                                            $fp=fopen($file1,"r");
                                            fgets($fp);
                                            fgets($fp);
                                            fgets($fp);
                                            for($i=0;$i<$num;$i++){
                                            $j=$i+1;
                                            echo "<tr>";
                                                $line=fgets($fp);
                                                $arr=explode(",",$line);
                                                $recv=round($arr[2]/1024)/1000;
                                                $sent=round($arr[3]/1024)/1000;
                                                echo "<th>".$j."</th>";
                                            echo "<td>UDP137模式：".$arr[0]."</td>";
                                            echo "<td>".$recv."MB</td>";
                                            echo "<td>".$sent."MB</td>";
                                            echo "</tr>";
                                            }
                                            ?>
										<br>
                                            <?php
                                            $str=file_get_contents($file2);
                                            $num=(substr_count($str,date('Y'))-1)/2;
                                            $fp=fopen($file2,"r");
                                            fgets($fp);
                                            fgets($fp);
                                            fgets($fp);
                                            for($i=0;$i<$num;$i++){
                                            $j=$i+1;
                                            echo "<tr>";
                                                $line=fgets($fp);
                                                $arr=explode(",",$line);
                                                $recv=round($arr[2]/1024)/1000;
                                                $sent=round($arr[3]/1024)/1000;
                                                echo "<th>".$j."</th>";
                                            echo "<td>UDP138模式：".$arr[0]."</td>";
                                            echo "<td>".$recv."MB</td>";
                                            echo "<td>".$sent."MB</td>";
                                            echo "</tr>";
                                            }
                                            ?>
                                      </tbody>
                                  </table>
                      
                      </div>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
