<?php
$mod='blank';
include("../api.inc.php");
$title='实时监控';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body  page-fade">
<?php include 'nav.php';?>

            
          <div class="page-title">
          <div class="title-env">
		<div class="jumbotron">
			<h1><?php echo $title ?></h1>
		
			<p>
				 <code>您可在此处查看实时流量监控日志</code>
			</p>
		
		</div>
            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">日志明细</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

                    <?php
                    $myfile = fopen("../../../jiankong.log", "r") or die("Unable to open file!");
                    echo fread($myfile,filesize("../../../jiankong.log"));
                    fclose($myfile);
                    ?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
