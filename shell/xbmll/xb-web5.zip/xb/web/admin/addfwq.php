<?php
$mod='blank';
include("../api.inc.php");
$title='添加服务器';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body  page-fade">
<?php include 'nav.php';?>

            
          <div class="page-title">
          <div class="title-env">
		<div class="jumbotron">
			<h1><?php echo $title ?></h1>
		
			<p>
				 <code>您可在此处增加多个服务器在此平台维护</code>
			</p>
		
		</div>


		   
            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">请输入服务器信息</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

                      <?php
                      if($_POST['name']){
                      echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>';
                      $name = daddslashes($_POST['name']);
                      $ipport = daddslashes($_POST['ipport']);

                      if(!$DB->get_row("select * from `auth_fwq` where `name`='$name' limit 1")){
                        $sql="insert into `auth_fwq` (`name`,`ipport`) values ('{$name}','{$ipport}')";
                        if($DB->query($sql))
                          echo "成功添加一个服务器";
                        else
                          echo "添加失败：".$DB->error();
                      }else{
                        echo "<script>alert('该服务器已存在！');history.go(-1);</script>";
                      }
                      echo '</div>';
                      //exit;
                      }
                      ?>


              <form action="./addfwq.php" method="post" role="form" class="form-horizontal validate">
                
                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" id="field-1" placeholder="服务器名称" name="name" data-validate="required">
                  </div>
                </div>

                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" id="field-1" placeholder="ip地址:端口" name="ipport" data-validate="required">
                  </div>
                </div>

                <button type="submit" type="button" class="btn btn-info">添加</button>
                
              </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
