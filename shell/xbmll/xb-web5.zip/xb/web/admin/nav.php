<?php
$url = $_SERVER['PHP_SELF'];
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$count=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
$count2=$DB->count("SELECT count(*) from `openvpn` WHERE i=1");
$countdaili=$DB->count("SELECT count(*) from `auth_daili` WHERE 1");
$countdaili2=$DB->count("SELECT count(*) from `auth_daili` WHERE active=0");
$countkm=$DB->count("SELECT count(*) from `auth_kms` WHERE 1");
$countkm2=$DB->count("SELECT count(*) from `auth_kms` WHERE isuse=0");
?>
<div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
	
	<div class="sidebar-menu">

		<div class="sidebar-menu-inner">
			
			<header class="logo-env">

				<!-- logo -->
				<div class="logo">
					<a href="index.html">
						<img src="../assets/images/logo@2x.png" width="120" alt="" />
					</a>
				</div>

				<!-- logo collapse icon -->
				<div class="sidebar-collapse">
					<a href="#" class="sidebar-collapse-icon"><!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
						<i class="entypo-menu"></i>
					</a>
				</div>

								
				<!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
				<div class="sidebar-mobile-menu visible-xs">
					<a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
						<i class="entypo-menu"></i>
					</a>
				</div>

			</header>
			
									
			<ul id="main-menu" class="main-menu">
				<!-- add class "multiple-expanded" to allow multiple submenus to open -->
				<!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
				<li>
					<a href="/adminuser">
						<i class="entypo-gauge"></i>
						<span class="title">平台首页</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="entypo-monitor"></i>
						<span class="title">服务管理</span>
					</a>
					<ul>
						<li>
							<a href="addfwq.php">
								<span class="title">添加服务器</span>
							</a>
						<li>
                            <li>
                            <a href="fwqlist.php">
                                 <span class="title">服务器列表</span>
                            </a>
                        </li>


						</li>

					</ul>
				</li>

				<li>
					<a href="#">
						<i class="entypo-newspaper"></i>
						<span class="title">账号管理</span>
					</a>
                        <ul>
                            <li>
                                <a href="pladd.php">
                                    <span class="title">批量添加账号</span>
                                </a>
                            </li>
                            <li>
                                <a href="addqq.php">
                                    <span class="title">添加账号</span>
                                </a>
                            </li>
                            <li>
                                <a href="qqlist.php">
                                    <span class="title">账号列表</span>
                                    <span class="label label-success pull-right"><?php echo $count?></span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">
                            <i class="entypo-box"></i>
                            <span class="title">卡密管理</span>
                        </a>
                        <ul>
                            <li>
                                <a href="kmtype.php">
                                    <span class="title">套餐管理</span>
                                    <span class="badge badge-info badge-roundless">New</span>
                                </a>
                            </li>
                            <li>
                                <a href="kmlist.php">
                                    <span class="title">商品列表</span>
                                </a>
                            </li>
                            <li>
                                <a href="search.php">
                                    <span class="title">内容搜索</span>
                                </a>
                            </li>
                        </ul>
                    </li>
				<li>
					<a href="#">
						<i class="entypo-doc-text"></i>
						<span class="title">代理管理</span>
					</a>
                        <ul>
                            <li>
                                <a href="daili.php">
                                    <span class="title">代理用户管理</span>
                                </a>
                            </li>
                            <li>
                                <a href="dlkm.php">
                                    <span class="title">代理充值卡密</span>
                                </a>
                            </li>
                            <li>
                                <a href="dlconfig.php">
                                    <span class="title">代理页面管理</span>
                                </a>
                            </li>
                        </ul>
                    </li>
				<li>
					<a href="#">
						<i class="entypo-window"></i>
						<span class="title">官网管理</span>
					</a>
                        <ul>
                            <li>
                                <a href="website.php">
                                    <span class="title">基本设置</span>
                                </a>
                            </li>
                            <li>
                                <a href="banner.php">
                                    <span class="title">大图设置</span>
                                </a>
                            </li>
                            <li>
                                <a href="payset.php">
                                    <span class="title">支付宝设置</span>
                                </a>
                            </li>
                        </ul>
                    </li>
				<li>
					<a href="#">
						<i class="entypo-bag"></i>
						<span class="title">云端管理</span>
						<span class="badge badge-info badge-roundless">New</span>
					</a>
                        <ul>
                           <!-- <li>
                                <a href="open.php">
                                    <span class="title">云端①线路添加</span>
                                </a>
                            </li>
                            <li>
                                <a href="openlist.php">
                                    <span class="title">云端①线路列表</span>
                                </a>
                            </li> -->
							<li>
                                <a href="/app_api">
                                    <span class="title">小白流量卫士管理<span class="badge badge-info badge-roundless">New</span></span>
                                </a>
                            </li>
                            <li>
                                <a href="/dnsml/index.php">
                                    <span class="title">小白专用云端线路管理</span>
                                </a>
                            </li>
							<li>
                                <a href="notice.php">
                                    <span class="title">小白专用云端公告管理</span>
                                </a>
                            </li>
                        </ul>
                    </li>
				<li>
					<a href="#">
						<i class="entypo-flow-tree"></i>
						<span class="title">平台日志</span>
					</a>
                        <ul>
                            <li>
                                <a href="log.php">
                                    <span class="title">操作记录</span>
                                </a>
                            </li>
                            <li>
                                <a href="online.php">
                                    <span class="title">在线用户</span>
                                </a>
                            </li>
                            <li>
                                <a href="script.php">
                                    <span class="title">实时监控日志</span>
                                </a>
                            </li>
                        </ul>
                    </li>
					</ul>
				</li>
			</ul>
			
		</div>

	</div>
		<div class="main-content">
				
		<div class="row">
		
			<!-- Profile Info and Notifications -->
			<div class="col-md-6 col-sm-8 clearfix">
		
				<ul class="user-info pull-left pull-none-xsm">
		
					<!-- Profile Info -->
					<li class="profile-info dropdown"><!-- add class "pull-right" if you want to place this from right -->
		
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<img src="../assets/images/thumb-1@2x.png" alt="" class="img-circle" width="44" />
							欢迎您，超级管理员
						</a>
		

					</li>
		
				</ul>
				
				<ul class="user-info pull-left pull-right-xs pull-none-xsm">
		
					<!-- Raw Notifications -->
					<li class="notifications dropdown">
		
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
							<i class="entypo-attention"></i>
							<span class="badge badge-info"></span>
						</a>

					</li>
		
					<!-- Message Notifications -->
					<li class="notifications dropdown">
		
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
							<i class="entypo-mail"></i>
							<span class="badge badge-secondary"></span>
						</a>
		

					</li>
		
					<!-- Task Notifications -->
					<li class="notifications dropdown">
		
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
							<i class="entypo-list"></i>
							<span class="badge badge-warning"></span>
						</a>
		

		
					</li>
		

		
			</div>
		
		
			<!-- Raw Links -->
			<div class="col-md-6 col-sm-4 clearfix hidden-xs">
		
				<ul class="list-inline links-list pull-right">
		

		
					
					<li>
						
							<i class="entypo-chat"></i>
							小白免流™ 全新一代流控管理系统
		
							<span class="badge badge-success chat-notifications-badge is-hidden">0</span>
						
					</li>
		
					<li class="sep"></li>
		
					<li>
						<a href="login.php?logout">
							退出登录 <i class="entypo-logout right"></i>
						</a>
					</li>
				</ul>
		
			</div>
		
		</div>
		
		<hr />