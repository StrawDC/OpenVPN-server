<?php
/**
 * 添加模式
**/
$mod='blank';
include("../api.inc.php");
$title='添加模式';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body  page-fade">
<?php include 'nav.php';?>

            
          <div class="page-title">
          <div class="title-env">
		<div class="jumbotron">
			<h1>公告信息</h1>
		
			<p>
				 <h3>更改之后 直接刷新此界面 查看是否提交成功</h3>
			</p>
		
		</div>
            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">内公告信息</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">



                    <form action="./notice.php" method="post" class="form-horizontal" role="form">

                      <div class="form-group">
                        <label class="col-sm-2 control-label">公告内容：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="content" rows="6"><?php echo file_get_contents('../dnsml/meteor'); ?></textarea>
                        </div></div>
<?php
header("Content-Type:text/html;charset=utf-8");
if(isset($_POST['content'])){
	$res = file_put_contents('../dnsml/meteor',$_POST['content']);
	if(false===$res) 
		echo '写入失败,目录'.__DIR__.'权限不足';
}
?>
                   
                      <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-9">
                          <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                        </div>
                      </div>
                    </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
 

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">外公告信息</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">



                    <form action="./notice.php" method="post" class="form-horizontal" role="form">

                      <div class="form-group">
                        <label class="col-sm-2 control-label">公告内容：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="content1" rows="6"><?php echo file_get_contents('../dnsml/bdw'); ?></textarea>
                        </div></div>
<?php
header("Content-Type:text/html;charset=utf-8");
if(isset($_POST['content1'])){
	$res = file_put_contents('../dnsml/bdw',$_POST['content1']);
	if(false===$res) 
		echo '写入失败,目录'.__DIR__.'权限不足';
}
?>
                   
                      <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-9">
                          <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                        </div>
                      </div>
                    </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div> 
            <!-- Main Footer -->
            <?php include("../copy.php");?>
