<?php
/**
 * 套餐列表
**/
$mod='blank';
include("../api.inc.php");
$title='套餐管理';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body  page-fade">
<?php include 'nav.php';?>

            
          <div class="page-title">
          <div class="title-env">
		<div class="jumbotron">
			<h1><?php echo $title ?></h1>
		
			<p>
				 <code>您可在此处管理维护所有套餐</code>
			</p>
		
		</div>
<?php
if($_POST['name']){
echo '';
$name = daddslashes($_POST['name']);
$days = daddslashes($_POST['days']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$km_rmb = daddslashes($_POST['km_rmb']);
if(!$DB->get_row("select * from `kmtype` where `name`='$name' limit 1")){
  $sql="insert into `kmtype` (`name`,`days`,`maxll`,`km_rmb`) values ('{$name}','{$days}','{$maxll}','{$km_rmb}')";
  if($DB->query($sql))
    echo '<div class="alert alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  成功添加一个套餐</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="kmtype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                  <style>#addtype{display: none;}</style>';
  else
    echo '<div class="alert alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>添加失败：'.$DB->error().'</div>
                <a href="javascript:history.go(-1)" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="kmtype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#addtype{display: none;}</style>';
}else{
  echo "<script>alert('该套餐已存在！');history.go(-1);</script>";
}
echo '';
//exit;
}

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `kmtype` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div><style>#addtype{display: none;}</style>';
}

if(!empty($_GET['kw'])) {
  $sql=" `id`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE{$sql}");
  $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个套餐';
}else{
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE 1");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个套餐';
}

?>

            <div id="addtype" class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo $con; ?></h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
                    
                    <?php
                    $dl_rs=$DB->query("SELECT * FROM `auth_daili`");
                    while($dl_res = $DB->fetch($dl_rs))
                    { ?>
                    <a href="kmtype.php?dlid=<?=$dl_res['id']?>" class="btn btn-info"><?=$dl_res['user']?></a>
                    <?php }
                    ?>
                    

                    <br>
					<hr />
                    <div id="addtype_list" class="row">
                                        <?php

                                        $dlid = $_GET['dlid'];

                                        $rs=$DB->query("SELECT * FROM `kmtype` WHERE `dlid` = '$dlid'");
                                        while($res = $DB->fetch($rs))
                                        { ?>

                                        <div class="col-sm-4">
			<div class="tile-block tile-green" id="todo_tasks">
					
					<div class="tile-header">
					<a href="kmtype.php?my=del&id=<?=$res['id']?>" onclick="if(!confirm('你确实要删除此套餐吗？')){return false;}" class="xe-next" style="color: rgba(255, 255, 255, 0.50);">
						<i class="entypo-cancel"></i></a>
											<a href="#">
							<?=$res['name']?>
							
						</a>

                                              </div>

                                           <div class="tile-content">
                                              
                                              <ul class="todo-list">
                                                <li>
                                                  <div class="checkbox checkbox-replace color-white">
                                                    <input type="checkbox" />
                                                    <label><?=$res['days']?>天使用时间</label>
													</div>
                                                 
                                                </li>
                                                <li>
                                                   <div class="checkbox checkbox-replace color-white">
												    <input type="checkbox" />
                                                    <label><?=round(($res['maxll'])/1024/1024)?>GB流量</label>
													</div>
                                                </li>
                                                <li>
                                                   <div class="checkbox checkbox-replace color-white">
												   <input type="checkbox" />
                                                    <label><?=$res['km_rmb']?>元</label>
                                                  </div>
                                                </li>
                                              </ul>
                                              
                                            </div>
                                            <div class="xe-footer">
                                              <form action="kmlist.php?my=add" method="POST" class="form-inline validate">
                                                  <input type="text" class="hide" name="kmtype_id" value="<?=$res['id']?>" data-validate="required,number,min[1]">
                                                  <input type="text" class="hide" name="value" value="<?=$res['days']?>" data-validate="required,number,min[1]">
                                                  <input type="text" class="hide" name="values" value="<?=round(($res['maxll'])/1024/1024)?>" data-validate="required,number,min[1]">
                                                 <div class="input-group">
                                                    <input type="text" class="form-control" name="num" placeholder="开多少张卡？" data-validate="required,number,min[1]">
                                                 <span class="input-group-btn">
                                                     <button type="submit" class="btn btn-primary">生成</button></span>
                                                  </div>
                                              </form>
                                            </div>
                                          </div>
                                        </div>

                                        <?php }
                                        ?>
                    </div>
                      
                      <blockquote class="blockquote blockquote-success">
                                <form action="kmtype.php?my=add" method="POST" class="form-inline validate" style="overflow: hidden;">
                                <div class="form-group">
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="name" placeholder="套餐名称" data-validate="required">
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="days" placeholder="使用天数" data-validate="required,number,min[1]">
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="maxll" placeholder="流量（GB）" data-validate="required,number,min[1]">
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="km_rmb" placeholder="售价" data-validate="required,number,min[1]">
                                  </div>
                                  <button type="submit" class="btn btn-success">添加套餐</button>
                                </div>
                                </form>
                        </blockquote>
                            <div class="alert alert-success">
                            <button type="button" class="close">
                              <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                              <span class="sr-only">Close</span>
                            </button>此处仅添加代理商ID为0的套餐，就是管理员自己</div>
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
