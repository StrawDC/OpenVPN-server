<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='搜索商品';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body  page-fade">
<?php include 'nav.php';?>

            
          <div class="page-title">
          <div class="title-env">
		<div class="jumbotron">
			<h1><?php echo $title ?></h1>
		
			<p>
				 <code>您可在此处可以检索内容</code>
			</p>
		
		</div>
            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">输入信息搜索</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

                      <form action="./kmlist.php" method="get" role="form" class="form-inline validate">  
                        <div class="form-group">

                        <div class="form-group">

                          <select class="form-control" name="type">
                            <option value="1">卡密</option>
                            <option value="2">账号</option>
                          </select>
                            
                        </div>

                        <div class="form-group">
                          <input type="text" class="form-control" size="25" placeholder="内容" name="kw"  data-validate="required"/>
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-secondary btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
