<?php
		require('system.php');
		$admin = db("app_admin")->where(array("username"=>$_SESSION["dd"]["username"],"password"=>$_SESSION["dd"]["password"]))->find();
		if(!$admin){
			if(!$login_allow){
				header("location:login.php?head=no");	
				exit;
			}
		
		}
		
		
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>小白流量卫士云端控制台</title>
<meta charset="utf-8"> 
<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="/app_api/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="/app_api/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="/app_api/css/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="/app_api/css/bootstrap.min.js"></script>
</head>
<style>
body,html{
	background:#efefef;
	background-attachment:fixed;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style>
<body>
<div style="padding:0px;padding-bottom:20px;">
